function x = x3sigma(sigma)
  x = -ceil(3*sigma):ceil(3*sigma);
end